package com.wetapp.petHospital.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Accessors(chain = true)
public class Stay {

    private  int id;
    private  String pet;
    private  String petType;
    private  String avatar_url;
    private  String stayType;
    private  String medical_card;

    public Stay(String pet, String petType, String avatar_url, String stayType, String medical_card) {
        this.pet = pet;
        this.petType = petType;
        this.avatar_url = avatar_url;
        this.stayType = stayType;
        this.medical_card = medical_card;
    }

    @Override
    public String toString() {
        return "Stay{" +
                "id=" + id +
                ", pet='" + pet + '\'' +
                ", petType='" + petType + '\'' +
                ", avatar_url='" + avatar_url + '\'' +
                ", stayType='" + stayType + '\'' +
                ", medical_card='" + medical_card + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPet() {
        return pet;
    }

    public void setPet(String pet) {
        this.pet = pet;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public void setAvatar_url(String avatar_url) {
        this.avatar_url = avatar_url;
    }

    public String getStayType() {
        return stayType;
    }

    public void setStayType(String stayType) {
        this.stayType = stayType;
    }

    public String getMedical_card() {
        return medical_card;
    }

    public void setMedical_card(String medical_card) {
        this.medical_card = medical_card;
    }
}
