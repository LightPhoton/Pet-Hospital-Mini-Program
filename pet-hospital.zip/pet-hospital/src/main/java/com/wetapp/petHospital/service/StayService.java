package com.wetapp.petHospital.service;

import com.wetapp.petHospital.domain.Stay;

import java.util.List;

public interface StayService {
    List<Stay> find(String medical_card);
}
