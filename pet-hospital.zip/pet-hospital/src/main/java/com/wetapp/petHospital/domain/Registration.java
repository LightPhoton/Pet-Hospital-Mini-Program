package com.wetapp.petHospital.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Accessors(chain = true)
public class Registration {

    private  int id;
    private  String petType;
    private  String doctor;
    private  String date;
    private  String introduction;
    private  String medical_card;

    public Registration(String petType, String doctor, String date, String introduction, String medical_card) {
        this.petType = petType;
        this.doctor = doctor;
        this.date = date;
        this.introduction = introduction;
        this.medical_card = medical_card;
    }

    @Override
    public String toString() {
        return "Registration{" +
                "id=" + id +
                ", petType='" + petType + '\'' +
                ", doctor='" + doctor + '\'' +
                ", date='" + date + '\'' +
                ", introduction='" + introduction + '\'' +
                ", medical_card='" + medical_card + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getMedical_card() {
        return medical_card;
    }

    public void setMedical_card(String medical_card) {
        this.medical_card = medical_card;
    }
}
