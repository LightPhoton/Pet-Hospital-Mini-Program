package com.wetapp.petHospital.domain;

public class Agency {
    private  int ano;
    private  String aname;
    private  String pwd;

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getAname() {
        return aname;
    }

    public void setAname(String aname) {
        this.aname = aname;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    @Override
    public String toString() {
        return "Agency{" +
                "ano=" + ano +
                ", aname='" + aname + '\'' +
                ", pwd='" + pwd + '\'' +
                '}';
    }
}
