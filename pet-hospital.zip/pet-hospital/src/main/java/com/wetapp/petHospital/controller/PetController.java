package com.wetapp.petHospital.controller;

import com.wetapp.petHospital.domain.Pet;
import com.wetapp.petHospital.service.FileService;
import com.wetapp.petHospital.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/Pet")
public class PetController {

    @Autowired
    PetService petService;
    @Autowired
    FileService fileService;

    @RequestMapping("/get")
    public Map<String, Object> getPet(@RequestParam(name = "medical_card") String medical_card) throws Exception {

        System.out.println("medical_card:" + medical_card);


        Map<String, Object> map = new HashMap<String, Object>();
        List<Pet> list = petService.findByMedical_card(medical_card);

        map.put("list", list);
        System.out.println(list);
        return map;
    }

    @RequestMapping("/delete")
    public boolean delPet(@RequestParam(name = "id") int id) throws Exception {
        System.out.println("id:" + id);

        Map<String, Object> map = new HashMap<String, Object>();
        boolean is = petService.delete(id);


        return is;

    }

    //add宠物 + 上传宠物头像
    @RequestMapping("/add")
    @ResponseBody
    public boolean addPet(@RequestParam(name = "name") String name,@RequestParam(name = "petType") String petType,
                          @RequestParam(name = "medical_card") String medical_card,@RequestParam("file") MultipartFile file
                          ) throws Exception {
        System.out.println("pet:" + name);
        System.out.println("petType:" + petType);
        System.out.println("medical_card:" + medical_card);
        System.out.println("file:" + file);

        // 获取上传文件
        String url = fileService.upload(file);
        System.out.println(url);

        Pet pet = new Pet(name,petType,url,medical_card);

        boolean is = petService.insert(pet);

        return is;

//        if (!file.isEmpty()) {
//            try {
//                /*
//                 * 这段代码执行完毕之后，图片上传到了工程的跟路径； 大家自己扩散下思维，如果我们想把图片上传到
//                 * d:/files大家是否能实现呢？ 等等;
//                 * 这里只是简单一个例子,请自行参考，融入到实际中可能需要大家自己做一些思考，比如： 1、文件路径； 2、文件名；
//                 * 3、文件格式; 4、文件大小的限制;
//                 */
//                BufferedOutputStream out = new BufferedOutputStream(
//                        new FileOutputStream(new File(
//                                file.getOriginalFilename())));
//                System.out.println(file.getName());
//                out.write(file.getBytes());
//                out.flush();
//                out.close();
//            } catch (FileNotFoundException e) {
//                e.printStackTrace();
//                System.out.println("上传失败," + e.getMessage());
//            } catch (IOException e) {
//                e.printStackTrace();
//                System.out.println("上传失败," + e.getMessage());
//            }
//        }
//        Map<String, Object> map = new HashMap<String, Object>();
//        boolean is = petService.delete(id);




    }


}
