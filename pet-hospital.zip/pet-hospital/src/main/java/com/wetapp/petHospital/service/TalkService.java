package com.wetapp.petHospital.service;

import com.wetapp.petHospital.domain.Talk;

import java.util.List;

public interface TalkService {
    List<Talk> findAll();
    boolean insert(Talk talk);
}
