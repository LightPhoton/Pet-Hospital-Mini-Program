package com.wetapp.petHospital.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Accessors(chain = true)
public class Talk {

    private  int id;
    private  String user_name;
    private  String message;
    private  String avatar_url;
    private  String medical_card;

    public Talk(String user_name, String message, String avatar_url, String medical_card) {
        this.user_name = user_name;
        this.message = message;
        this.avatar_url = avatar_url;
        this.medical_card = medical_card;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public void setAvatar_url(String avatar_url) {
        this.avatar_url = avatar_url;
    }

    public String getMedical_card() {
        return medical_card;
    }

    public void setMedical_card(String medical_card) {
        this.medical_card = medical_card;
    }

    @Override
    public String toString() {
        return "Talk{" +
                "id=" + id +
                ", user_name='" + user_name + '\'' +
                ", message='" + message + '\'' +
                ", avatar_url='" + avatar_url + '\'' +
                ", medical_card='" + medical_card + '\'' +
                '}';
    }
}
