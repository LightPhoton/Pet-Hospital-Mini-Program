package com.wetapp.petHospital.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Accessors(chain = true)
public class Medical_history {

    private  int id;
    private  String doctor;
    private  String date;
    private  String pet;
    private  String petType;
    private  String introduction;
    private  String medical_card;

    public Medical_history(String doctor, String date, String pet, String petType, String introduction, String medical_card) {
        this.doctor = doctor;
        this.date = date;
        this.pet = pet;
        this.petType = petType;
        this.introduction = introduction;
        this.medical_card = medical_card;
    }

    @Override
    public String toString() {
        return "Medical_history{" +
                "id=" + id +
                ", doctor='" + doctor + '\'' +
                ", date='" + date + '\'' +
                ", pet='" + pet + '\'' +
                ", petType='" + petType + '\'' +
                ", introduction='" + introduction + '\'' +
                ", medical_card='" + medical_card + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPet() {
        return pet;
    }

    public void setPet(String pet) {
        this.pet = pet;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getMedical_card() {
        return medical_card;
    }

    public void setMedical_card(String medical_card) {
        this.medical_card = medical_card;
    }
}
