package com.wetapp.petHospital.mapper;

import com.wetapp.petHospital.domain.Agency;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface AgencyXmlMapper {

    public List<Agency> findAll();
}
