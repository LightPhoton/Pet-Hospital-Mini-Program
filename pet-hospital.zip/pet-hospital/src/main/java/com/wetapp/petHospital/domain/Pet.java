package com.wetapp.petHospital.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Accessors(chain = true)
public class Pet {

    private  int id;
    private  String name;
    private  String petType;
    private  String avatar_url;
    private  String medical_card;

    public Pet(String name, String petType, String avatar_url, String medical_card) {
        this.name = name;
        this.petType = petType;
        this.avatar_url = avatar_url;
        this.medical_card = medical_card;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public void setAvatar_url(String avatar_url) {
        this.avatar_url = avatar_url;
    }


    public String getMedical_card() {
        return medical_card;
    }

    public void setMedical_card(String medical_card) {
        this.medical_card = medical_card;
    }

    @Override
    public String toString() {
        return "Pet{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", petType='" + petType + '\'' +
                ", avatar_url='" + avatar_url + '\'' +
                ", medical_card='" + medical_card + '\'' +
                '}';
    }
}
