package com.wetapp.petHospital.service.impl;

import com.wetapp.petHospital.domain.Stay;
import com.wetapp.petHospital.mapper.StayMapper;
import com.wetapp.petHospital.service.StayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class StayServiceimpl  implements StayService {

    @Autowired
    StayMapper stayMapper;
    @Override
    public List<Stay> find(String medical_card) {
        List<Stay> list = stayMapper.find(medical_card);
        return list;
    }
}
