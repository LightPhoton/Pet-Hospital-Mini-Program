package com.wetapp.petHospital.service;

import com.wetapp.petHospital.domain.Registration;

import java.util.List;

public interface RegistrationService {
    boolean insert(Registration registration);
    boolean delete(int id);
    List<Registration> find(String medical_card);
}
