package com.wetapp.petHospital.service.impl;

import com.wetapp.petHospital.domain.Medical_history;
import com.wetapp.petHospital.mapper.Medical_historyMapper;
import com.wetapp.petHospital.service.Medical_historyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class Medical_historyServiceimpl implements Medical_historyService {

    @Autowired
    Medical_historyMapper medical_historyMapper;
    @Override
    public List<Medical_history> find(String medical_card) {
        List<Medical_history> list = medical_historyMapper.find(medical_card);
        return list;
    }
}
