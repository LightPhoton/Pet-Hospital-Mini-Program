package com.wetapp.petHospital.controller;


import com.wetapp.petHospital.domain.Pet;
import com.wetapp.petHospital.domain.Stay;
import com.wetapp.petHospital.service.StayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/Stay")
public class StayController {

    @Autowired
    StayService stayService;

    @RequestMapping("/get")
    public Map<String, Object> getStay(@RequestParam(name = "medical_card") String medical_card) throws Exception {

        System.out.println("medical_card:" + medical_card);

        Map<String, Object> map = new HashMap<String, Object>();
        List<Stay> list = stayService.find(medical_card);

        map.put("list", list);
        System.out.println(list);
        return map;
    }
}
