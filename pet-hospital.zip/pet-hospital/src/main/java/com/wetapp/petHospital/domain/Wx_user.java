package com.wetapp.petHospital.domain;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Accessors(chain = true)
public class Wx_user {

    private  int id;
    private  String wx_nickname;
    private  String open_id;
    private  String avatar_url;
    private  String medical_card;


    public Wx_user(String wx_nickname, String open_id, String avatar_url, String medical_card) {
        this.wx_nickname = wx_nickname;
        this.open_id = open_id;
        this.avatar_url = avatar_url;
        this.medical_card = medical_card;
    }

    @Override
    public String toString() {
        return "Wx_user{" +
                "id=" + id +
                ", wx_nickname='" + wx_nickname + '\'' +
                ", open_id='" + open_id + '\'' +
                ", avatar_url='" + avatar_url + '\'' +
                ", medical_card='" + medical_card + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWx_nickname() {
        return wx_nickname;
    }

    public void setWx_nickname(String wx_nickname) {
        this.wx_nickname = wx_nickname;
    }

    public String getOpen_id() {
        return open_id;
    }

    public void setOpen_id(String open_id) {
        this.open_id = open_id;
    }

    public String getAvatar_url() {
        return avatar_url;
    }

    public void setAvatar_url(String avatar_url) {
        this.avatar_url = avatar_url;
    }

    public String getMedical_card() {
        return medical_card;
    }

    public void setMedical_card(String medical_card) {
        this.medical_card = medical_card;
    }
}
