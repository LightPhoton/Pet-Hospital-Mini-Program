package com.wetapp.petHospital.controller;


import com.wetapp.petHospital.domain.Medical_history;
import com.wetapp.petHospital.service.Medical_historyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/Medical_history")
public class Medical_historyController {

    @Autowired
    Medical_historyService medical_historyService;

    @RequestMapping("/get")
    public Map<String, Object> getMedical_history(String medical_card) {

        System.out.println("medical_card:" + medical_card);

        Map<String, Object> map = new HashMap<String, Object>();
        List<Medical_history> list = medical_historyService.find(medical_card);

        map.put("list", list);
        System.out.println(list);
        return map;
    }
}
