package com.wetapp.petHospital.service.impl;

import com.wetapp.petHospital.domain.Talk;
import com.wetapp.petHospital.mapper.TalkMapper;
import com.wetapp.petHospital.service.TalkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TalkServiceimpl implements TalkService {

    @Autowired
    TalkMapper talkMapper;
    @Override
    public List<Talk> findAll() {
        List<Talk> list = talkMapper.findAll();
        return list;
    }

    @Override
    public boolean insert(Talk talk) {

        return talkMapper.insert(talk)>0;
    }
}
