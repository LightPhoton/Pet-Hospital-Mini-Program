package com.wetapp.petHospital.mapper;


import com.wetapp.petHospital.domain.Talk;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface TalkMapper {

//    @Select("select * from Talk")
    public List<Talk> findAll();
    int insert(Talk talk);
}
