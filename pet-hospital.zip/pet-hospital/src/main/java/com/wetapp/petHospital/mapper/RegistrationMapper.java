package com.wetapp.petHospital.mapper;

import com.wetapp.petHospital.domain.Registration;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface RegistrationMapper {

//    @Select("select * from Registration")
    public List<Registration> findAll();
    int insert(Registration registration);
    int delete(int id);
    List<Registration> find(String medical_card);
}
