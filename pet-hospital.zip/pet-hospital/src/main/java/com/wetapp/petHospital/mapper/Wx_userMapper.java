package com.wetapp.petHospital.mapper;


import com.wetapp.petHospital.domain.Wx_user;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface Wx_userMapper {

//    @Select("select * from wx_user")
    public List<Wx_user> findAll();
    //增加
    int insert(Wx_user wx_user);
    String getMedical_card(String openid);
    Wx_user selectByMedical_card(String medical_card);

    public List<Wx_user> selectByOpen_id(String openid);
    public int verifyOpen_id(String openid);

}
