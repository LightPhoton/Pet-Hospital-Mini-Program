package com.wetapp.petHospital.service;

import com.wetapp.petHospital.domain.Medical_history;

import java.util.List;

public interface Medical_historyService {
    List<Medical_history> find(String medical_card);
}
