package com.wetapp.petHospital.service.impl;

import com.wetapp.petHospital.domain.Registration;
import com.wetapp.petHospital.mapper.RegistrationMapper;
import com.wetapp.petHospital.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegistrationServiceimpl implements RegistrationService {
    @Autowired
    RegistrationMapper registrationMapper;
    @Override
    public boolean insert(Registration registration) {
        return registrationMapper.insert(registration)>0;
    }

    @Override
    public boolean delete(int id) {
        return registrationMapper.delete(id)>0;
    }

    @Override
    public List<Registration> find(String medical_card) {
        List<Registration> list = registrationMapper.find(medical_card);
        return list;
    }
}
