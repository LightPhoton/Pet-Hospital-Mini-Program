package com.wetapp.petHospital.service.impl;

import com.wetapp.petHospital.domain.Pet;
import com.wetapp.petHospital.mapper.PetMapper;
import com.wetapp.petHospital.service.PetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PetServiceimpl implements PetService {

    @Autowired
    PetMapper petMapper;
    @Override
    public boolean insert(Pet pet) {

        return petMapper.insert(pet)>0;
    }

    @Override
    public boolean update(Pet pet) {
        return false;
    }

    @Override
    public boolean delete(int id) {

        return petMapper.delete(id)>0;
    }

    @Override
    public List<Pet> findByMedical_card(String medical_card) {
        List<Pet> list = petMapper.selectByMedical_card(medical_card);
        return list;
    }

    @Override
    public Pet findById(int id) {
        return null;
    }
}
