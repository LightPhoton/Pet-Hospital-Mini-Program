package com.wetapp.petHospital.service;


import com.wetapp.petHospital.domain.Wx_user;

import java.util.List;

/**
 * 歌手service接口
 */
public interface Wx_userService {
    //增加
    boolean insert(Wx_user wx_user);
    //修改
    boolean update(Wx_user wx_user);
    //删除
    boolean delete(String medical_card);

    //根据openid查询用户medical_card
    String getMedical_card(String openid);
    //根据medical_card查询整个对象
    Wx_user selectByMedical_card(String medical_card);
    //校验是否注册过
    boolean verifyOpen_id(String openid);
    //查询所有的用户
    List<Wx_user> allWx_user();
    //根据用户名字模糊查询列表
    List<Wx_user> Wx_userOfName(String name);

}

