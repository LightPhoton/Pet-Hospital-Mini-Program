package com.wetapp.petHospital.controller;

import com.wetapp.petHospital.domain.Pet;
import com.wetapp.petHospital.domain.Registration;
import com.wetapp.petHospital.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/Registration")
public class RegistrationController {

    @Autowired
    RegistrationService registrationService;
    @RequestMapping("/insert")
    public int insert(@RequestParam(name = "petType") String petType,@RequestParam(name = "doctor") String doctor,
                          @RequestParam(name = "date") String date,@RequestParam(name = "introduction") String introduction,
                          @RequestParam(name = "medical_card") String medical_card) throws Exception {
        System.out.println("petType:" + petType);
        System.out.println("doctor:" + doctor);
        System.out.println("date:" + date);
        System.out.println("introduction:" + introduction);
        System.out.println("medical_card:" + medical_card);

        Registration registration = new Registration(petType,doctor,date,introduction,medical_card);
        boolean is = registrationService.insert(registration);
        int i=0;
        if(is==true)
            i=1;
        System.out.println(is);
        return i;

    }

    @RequestMapping("/get")
    public Map<String, Object> getPet(@RequestParam(name = "medical_card") String medical_card) throws Exception {

        System.out.println("medical_card:" + medical_card);

        Map<String, Object> map = new HashMap<String, Object>();
        List<Registration> list = registrationService.find(medical_card);

        map.put("list", list);
        System.out.println(list);
        return map;
    }

    @RequestMapping("/delete")
    public boolean delPet(@RequestParam(name = "id") int id) throws Exception {
        System.out.println("id:" + id);

        Map<String, Object> map = new HashMap<String, Object>();
        boolean is = registrationService.delete(id);
        return is;

    }

}
