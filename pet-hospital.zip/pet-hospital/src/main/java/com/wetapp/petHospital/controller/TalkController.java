package com.wetapp.petHospital.controller;

import com.wetapp.petHospital.domain.Talk;
import com.wetapp.petHospital.service.TalkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/Talk")
public class TalkController {

    @Autowired
    TalkService talkService;
    @RequestMapping("/insert")
    public Map<String, Object> insert(@RequestParam(name = "user_name") String user_name, @RequestParam(name = "message") String message,
                      @RequestParam(name = "avatar_url") String avatar_url, @RequestParam(name = "medical_card") String medical_card) throws Exception {
        System.out.println("user_name:" + user_name);
        System.out.println("message:" + message);
        System.out.println("avatar_url:" + avatar_url);
        System.out.println("medical_card:" + medical_card);

        Talk talk = new Talk(user_name,message,avatar_url,medical_card);
        boolean is = talkService.insert(talk);
        System.out.println(is);

        Map<String, Object> map = new HashMap<String, Object>();
        List<Talk> list = talkService.findAll();

        map.put("list", list);
        System.out.println(list);
        return map;

    }

    @RequestMapping("/get")
    public Map<String, Object> getTalk() throws Exception {

//        System.out.println("medical_card:" + medical_card);

        Map<String, Object> map = new HashMap<String, Object>();
        List<Talk> list = talkService.findAll();

        map.put("list", list);
        System.out.println(list);
        return map;
    }
}
