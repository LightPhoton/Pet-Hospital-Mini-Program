package com.wetapp.petHospital.service;

import com.wetapp.petHospital.domain.Pet;
import com.wetapp.petHospital.domain.Wx_user;

import java.util.List;

public interface PetService {

    //增加
    boolean insert(Pet pet);
    //修改
    boolean update(Pet pet);
    //删除
    boolean delete(int id);
    //使用medical_card查找
    List<Pet> findByMedical_card(String medical_card);

    //使用medical_card查找
    Pet findById(int id);

}
