package com.wetapp.petHospital.service.impl;

import com.wetapp.petHospital.domain.Wx_user;
import com.wetapp.petHospital.mapper.Wx_userMapper;
import com.wetapp.petHospital.service.Wx_userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Wx_userServiceimpl implements Wx_userService {

    /**
     * 注入mapper
     */
    @Autowired
    private Wx_userMapper wx_userMapper;

    @Override
    public boolean insert(Wx_user wx_user) {

        return wx_userMapper.insert(wx_user) > 0;
    }

    @Override
    public boolean update(Wx_user wx_user) {
        return false;
    }

    @Override
    public boolean delete(String medical_card) {
        return false;
    }

    @Override
    public String getMedical_card(String openid) {
        String medical_card = wx_userMapper.getMedical_card(openid);
        return medical_card;
    }

    @Override
    public Wx_user selectByMedical_card(String medical_card) {
        Wx_user wx_user = wx_userMapper.selectByMedical_card(medical_card);
        return wx_user;
    }

    @Override
    public boolean verifyOpen_id(String openid) {
        int is = wx_userMapper.verifyOpen_id(openid);
        return is==0;
    }


    @Override
    public List<Wx_user> allWx_user() {
        List<Wx_user> list = wx_userMapper.findAll();
        return list;
    }

    @Override
    public List<Wx_user> Wx_userOfName(String name) {
        return null;
    }
}
