package com.wetapp.petHospital.mapper;


import com.wetapp.petHospital.domain.Pet;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface PetMapper {

//    @Select("select * from pet")
    public List<Pet> findAll();
    List<Pet> selectByMedical_card(String medical);
    int insert(Pet pet);
    int delete(int id);
}
