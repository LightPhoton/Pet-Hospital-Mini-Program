package com.wetapp.petHospital.mapper;


import com.wetapp.petHospital.domain.Stay;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface StayMapper {

//    @Select("select * from Stay")
    public List<Stay> findAll();
    List<Stay> find(String medical_card);

}
