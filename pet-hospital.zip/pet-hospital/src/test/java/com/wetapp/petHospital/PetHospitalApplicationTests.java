package com.wetapp.petHospital;

import com.wetapp.petHospital.domain.Agency;
import com.wetapp.petHospital.domain.Medical_history;
import com.wetapp.petHospital.domain.Pet;
import com.wetapp.petHospital.domain.Wx_user;
import com.wetapp.petHospital.mapper.AgencyMapper;
import com.wetapp.petHospital.mapper.Medical_historyMapper;
import com.wetapp.petHospital.mapper.Wx_userMapper;
import com.wetapp.petHospital.service.PetService;
import com.wetapp.petHospital.service.Wx_userService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Random;
import java.util.UUID;

@SpringBootTest
class PetHospitalApplicationTests {

    @Autowired
    private AgencyMapper agencyMapper;
    @Autowired
    private AgencyMapper agencyXmlMapper;


    @Autowired
    private Wx_userService wx_userService;
    @Autowired
    private Wx_userMapper  wx_userMapper;

    @Autowired
    PetService petService;


    @Autowired
    Medical_historyMapper medical_historyMapper;



    @Test
    public void  testFindAll() {
        List<Agency> list = agencyMapper.findAll();
        System.out.println(list);
    }

    @Test
    public void  testFindAll2() {
        List<Agency> list = agencyXmlMapper.findAll();
        System.out.println(list);
    }

    String openid = "oAOIz5FzA4AyQV0bfe-tiRaVc2Qc";
    int id = 1;
    @Test
    public void  testFindWx_userAll() {

        List<Wx_user> list = wx_userMapper.findAll();
        System.out.println(list.get(0).getAvatar_url());
        System.out.println(list);
    }
    @Test
    public void  testFindWx_user() {

        List<Wx_user> list = wx_userMapper.selectByOpen_id(openid);
        if(list.isEmpty())
            System.out.println("空");
        System.out.println(list);
    }
    @Test
    public void  testFindOpenid() {
        int is= wx_userMapper.verifyOpen_id(openid);
        if(is==0)
            System.out.println("空");
        System.out.println(is);
    }
    @Test
    public void testGetMedical_card(){
        String medical_card = wx_userService.getMedical_card(openid);
        System.out.println(medical_card);
    }
    @Test
    public void testSelectByMedical_card(){
        Wx_user wx_user = wx_userService.selectByMedical_card("440184199506123691");
        System.out.println(wx_user);
    }
//    @Test
//    public void  testInsertWx_user() {
//        Wx_user wx_user = new Wx_user();
//        wx_user.setWx_nickname("发起人");
//        wx_user.setMedical_card("928098489095095012");
//        wx_user.setAvatar_url("http://sadasd.dasdawfafeuasbahsjnc.aiwudhw8udhaiwaow.jpg");
//        wx_user.setOpen_id("as56a10f0waf1wa89f60faw5f00wa");
//        boolean is= wx_userService.insert(wx_user);
//        if(is)
//            System.out.println("c成功");
//        System.out.println(is);
//    }

    @Test
    void testFindPetByMedical_card() {
        List<Pet> list = petService.findByMedical_card("440184199506123691");
        System.out.println(list);
    }
    @Test
    void testDelPetByid() {
        boolean is = petService.delete(id);
        System.out.println(is);
    }

    @Test
    public void  testFindMedical_historyAll() {
        List<Medical_history> list = medical_historyMapper.findAll();
        System.out.println(list);
    }

    @Test
    public void testCreatMedical_ard() {
        StringBuilder stringBuilder = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 18; i++) {
            int i1 = random.nextInt(10);
            stringBuilder.append(i1);
        }
        System.out.println(stringBuilder.toString());
        String medical_card = stringBuilder.toString();
        System.out.println(medical_card);
    }

    @Test
    public void testUuid() {
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        System.out.println(uuid);
    }
}
