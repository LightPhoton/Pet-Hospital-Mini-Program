
var app = getApp();

Page({
	data: {
		textareaDatas: [],
		
		regList: [],
		medical_card:'',
	},
	onLoad(option) {
		this.setData({
			medical_card: app.globalData.medical_card
		})
		// console.log(medical_card);
		// console.log(app.globalData.medical_card);
		this.getReg();
	},

	async getReg(){
		var that = this;
		var medical_card = that.data.medical_card;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Registration/get',
			data: {
				medical_card: medical_card,
			}
		})
		console.log(res);
		this.setData({
			regList:res.list
		})
		console.log(this.data.regList);
	},
	
	delReg : async function (e) {
		var that = this;
		var id = that.data.regList[e.currentTarget.dataset.index].id;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Registration/delete',
			data: {
				id: id,
				
			}
		})
		that.data.regList.splice(e.currentTarget.dataset.index,1);
		console.log(res);
		console.log(that.data.regList);
		
		that.setData({
			regList:that.data.regList
		})
	},

});
