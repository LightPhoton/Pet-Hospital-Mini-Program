var util = require('../../../utils/utils.js');
var app = getApp();
Page({
	data: {
		radioDatas: [
			{ value: '猫', label: '猫' },
			{ value: '狗', label: '狗' },
			{ value: '其他', label: '其他' }
		],
		radioLabel: '',
		radio1Datas: [
			{ value: '谢医生', label: '谢医生' },
			{ value: '周医生', label: '周医生' }
		],
		radio1Label: '',
		textareaDatas: [],
		textarea: '',
		date: [],
		date1: [],
		medical_card: ''
	},
	bindDateChange: function(e) {
		console.log('picker发送选择改变，携带值为', e.detail.value)
		this.setData({
		  date: e.detail.value
		})
	},
	onLoad(option) {
		var that = this;
		if (option) {
			this.setData({
				globalOption: option
			});
		}
		if (app.globalData.medical_card) {
			this.setData({
				
				medical_card: app.globalData.medical_card
			})
        }
		var date = util.formatDate(new Date());
		var date1 = util.formatDate1(new Date());

		this.setData({
			date: date,
			date1: date1
		});
		console.log(this.data.date)
		console.log(this.data.date1)
		
	},
	onShow() {
		this.init();
	},
	async init() {
		await this.getForm();
	},
	getForm() {
		this.validateForm = this.Validate({
			radio: {
				required: {
					message: '请选择科室'
				}
			},
			radio1: {
				required: {
					message: '请选择医生'
				}
			}
		});
		if (this.globalOption && this.globalOption.id) {
			//调用数据
			let param = {
				tableName: 'form'
			};
			param = this.$tools.extend(param, this.globalOption);
			//调用数据
			this.$request.getData(param).then((data) => {
				if (data.code == 200) {
					var row = data.rows[0];
					var values = {};
					for (let key in row) {
						var keyr = key.replace(new RegExp('-', 'gm'), '');
						if (this['change' + keyr]) {
							this['change' + keyr](row[key]);
						} else {
							values[key] = row[key];
						}
					}
					this.setData(values);
				} else {
					this.showModal(data.message);
				}
			});
		}
	},
	submitForm: function (e) {
		if (!this.validateForm.checkForm(e)) {
			const error = this.validateForm.errorList[0];
			this.showToast(error.msg, 'none');
			return false;
		} 
		else if(e.detail.value.textarea==''){
			wx.showModal({
                title: '提示',
                content:"请填写病情概况",
            })
            
            return false;
		}
		else
		{
			console.log(e.detail.value);
			this.TiJiao(e);
			// this.$request.saveData(e.detail.value).then((data) => {
			// 	if (data.code == 200) {
			// 		this.showToast(error.msg, 'success');
			// 	} else {
			// 		this.showModal(data.msg);
			// 	}
			// });
		}
	},

	async TiJiao(e) {
		var that = this;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Registration/insert',
			data:{
				petType: e.detail.value.radio,
				doctor: e.detail.value.radio1,
				date: that.data.date,
				introduction: e.detail.value.textarea,
				medical_card: that.data.medical_card
			},
			method: 'GET',
		})
		console.log(res)
		if(res==1){
		wx.showModal({
            title: '提示',
            content:"预约成功",
		});
		
		wx.navigateBack();}
	},

	resetForm: function () {
		console.log('form发生了reset事件');
	},
	changeRadio(evt) {
		let value = evt.detail.value;
		let radioDatas = this.data.radioDatas;
		let radioLabel = this.data.radioLabel;
		for (var i = 0, len = radioDatas.length; i < len; ++i) {
			radioDatas[i].checked = radioDatas[i].value == value;
			if (radioDatas[i].checked) {
				radioLabel = radioDatas[i].label;
			}
		}
		this.setData({ radioLabel, radioDatas });
	},
	changeRadio1(evt) {
		let value = evt.detail.value;
		let radio1Datas = this.data.radio1Datas;
		let radio1Label = this.data.radio1Label;
		for (var i = 0, len = radio1Datas.length; i < len; ++i) {
			radio1Datas[i].checked = radio1Datas[i].value == value;
			if (radio1Datas[i].checked) {
				radio1Label = radio1Datas[i].label;
			}
		}
		this.setData({ radio1Label, radio1Datas });
	}
});
