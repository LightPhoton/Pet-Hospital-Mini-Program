var app = getApp();
Page({
	data: {
		petList: [],
		medical_card:'',

	},
	onShow() {
		this.setData({
			medical_card: app.globalData.medical_card
		})
		// console.log(medical_card);
		// console.log(app.globalData.medical_card);
		this.getPet();
	},
	onLoad(option) {
		//进入页面---判断全局是否有数据
		var that = this;
		this.setData({
			medical_card: app.globalData.medical_card
		
		});
		this.getPet();
		// console.log(medical_card);
		// console.log(app.globalData.medical_card);
		

	},
	

	async getPet(){
		
		var that = this;
		var medical_card = that.data.medical_card;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Pet/get',
			data: {
				medical_card: medical_card,
			}
		})
		console.log(res);
		this.setData({
			petList:res.list
		})
		console.log(this.data.petList);
		
	},

	delPet : async function (e) {
		var that = this;
		var id = that.data.petList[e.currentTarget.dataset.index].id;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Pet/delete',
			data: {
				id: id,
				
			}
		})
		that.data.petList.splice(e.currentTarget.dataset.index,1);
		console.log(res);
		console.log(that.data.petList);
		
		that.setData({
		 	petList:that.data.petList
		})
	},

	// reWriteModal() {
	// 	wx.showModal({
	// 		title: '是否修改宠物信息？',
	// 		success: function (res) {
	// 			if (res.confirm) {
	// 				console.log('用户点击确定')
	// 				wx.navigateTo({
						
	// 				})
	// 			}
	// 		}
	// 	})
	// },
});
