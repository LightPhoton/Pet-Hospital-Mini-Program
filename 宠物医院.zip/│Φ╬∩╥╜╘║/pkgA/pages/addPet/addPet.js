// pkgA/pages/addPet/addPet.js
var Util = require('../../../utils/utils.js');

//获取应用实例
const app = getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        medical_card:'',
        radioDatas: [
			{ value: '猫', label: '猫' },
			{ value: '狗', label: '狗' },
			{ value: '其他', label: '其他' }
        ],
        
        name:'',
        petType:'',
        uploaderList: [],//临时路径
        tempFilePaths: '',
        uploaderNum:0,
        showUpload:true, //是否允许上传
        
    },

    async upLoad(){
        var that = this;
        const { data: res } = await wx.p.uploadFile({
            url: 'http://localhost:8080/Pet/add', 
            filePath: that.data.tempFilePaths[0],
            name: 'file',
            // header:{
            //     'content-type': 'application/json' // 默认值
            // },
            formData: {
                name: that.data.name,
                petType: that.data.petType,
                medical_card: that.data.medical_card
            },
            // success (res){
            //   const data = res.data
            //   //do something
            // }
        })
        console.log(res);
        if(res=="true")
            wx.navigateBack();
        else
        {
            wx.showModal({
                title: '提示',
                content:"添加失败",
            })
        }
    },

    //表单提交
    formSubmit: function (e) {
        
        e.detail.value.tempFilePaths = this.data.tempFilePaths;
        console.log('form发生了submit事件，携带数据为：', e.detail.value);
        
        this.setData({
            name: e.detail.value.name,
            petType: e.detail.value.petType,
            
        })
        if (e.detail.value.name == "" || e.detail.value.petType == "") {
            wx.showModal({
                title: '提示',
                content:"宠物名字为空或没选择宠物种类！",
            })
            
            return;
        }
        else{
            this.upLoad();
            // wx.request({
            //     url: 'http://localhost:8080/pet/',
            //     data:{
            //         pet: pet,
            //         petType: petType,
            //         medical_card: medical_card
            //     },
            //     method: 'GET',
            //     header: {
            //         'content-type': 'application/json' // 默认值
            //     },
            //     success: function (res) { //res是返回的数据，success是响应成功后执行部分
            //         console.log(res.data) //显示res中携带的数据
                    
            //     },
            // });
            
        }
    },

    //展示图片
    showImg:function(e){
        var that=this;
        wx.previewImage({
            urls: that.data.uploaderList,
            current: that.data.uploaderList[e.currentTarget.dataset.index]
        })
    },

    changeRadio(evt) {
		let value = evt.detail.value;
		let radioDatas = this.data.radioDatas;
		let radioLabel = this.data.radioLabel;
		for (var i = 0, len = radioDatas.length; i < len; ++i) {
			radioDatas[i].checked = radioDatas[i].value == value;
			if (radioDatas[i].checked) {
				radioLabel = radioDatas[i].label;
			}
		}
		this.setData({ radioLabel, radioDatas });
	},

    changeImg(){
        const that = this;
        wx.chooseImage({
            count: 1,   //可选图片数量，这里限制为1张
            sizeType: ['original', 'compressed'],
            sourceType: [ 'album', 'camera'],
            success(res) {
                var tempFilePaths = res.tempFilePaths;
                console.log(tempFilePaths);
                let uploaderList;
                that.setData({
                    tempFilePaths : tempFilePaths
                })
                if(that.data.uploaderList.length==1)
                    that.data.uploaderList.pop(); 
                uploaderList = that.data.uploaderList.concat(tempFilePaths);
                
                that.setData({
                        showUpload:false
                })
                that.setData({
                    uploaderList: uploaderList,
                    uploaderNum: uploaderList.length,
                })
                
            }
        })
    },
        
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        
        //进入页面后---获取本地存储是否有数据授权----------
		if (app.globalData.medical_card) {
			this.setData({
				
				medical_card: app.globalData.medical_card
			})
        }
    },

})