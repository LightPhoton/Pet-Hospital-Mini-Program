 
var app = getApp();
Page({
	data: {
		input1: '周医师',
		input2: '2022-4-11',
		input3: '小Dog',
		input4: '狗',
		textarea1Datas: [],
		textarea1: '流涕不止，食欲，精神不振，典型狗感冒症状，服用狗感冒药三副后复诊',

		medical_historyList: [],
		medical_card:'',
	},

	onShow() {
		this.setData({
			medical_card: app.globalData.medical_card
		})
		this.getmedical_history();
	},

	async getmedical_history(){
		
		var that = this;
		var medical_card = that.data.medical_card;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Medical_history/get',
			data: {
				medical_card: medical_card,
			}
		})
		console.log(res);
		this.setData({
			medical_historyList:res.list
		})
		console.log(this.data.medical_historyList);
		
	},

	onLoad(option) {
		
	},
	
	
});
