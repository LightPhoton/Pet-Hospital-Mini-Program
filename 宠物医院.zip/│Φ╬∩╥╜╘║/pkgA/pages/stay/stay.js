var app = getApp();
Page({
	data: {
		stayList: [],
		medical_card:'',
	},
	onShow() {
		this.setData({
			medical_card: app.globalData.medical_card
		})
		this.getStay();
	},

	async getStay(){
		
		var that = this;
		var medical_card = that.data.medical_card;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Stay/get',
			data: {
				medical_card: medical_card,
			}
		})
		console.log(res);
		this.setData({
			stayList:res.list
		})
		console.log(this.data.stayList);
		
	},

	onLoad(option) {
		
	},
	

});
