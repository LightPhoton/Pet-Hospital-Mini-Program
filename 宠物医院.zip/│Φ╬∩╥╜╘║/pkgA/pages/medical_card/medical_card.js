 
Page({
	data: {
		text: `<p>&nbsp; &nbsp; 本宠物医院小程序的宠物医疗服务需要绑定就诊卡后才能使用，请确保所填信息的真实性并认真填写！</p>`,
		input: '',
		input1: '',
		input2: '',
		radioDatas: [
			{ value: '1', label: '男' },
			{ value: '2', label: '女' }
		],
		radioLabel: '',
		textareaDatas: [],
		textarea: ''
	},
	onLoad(option) {
		if (option) {
			this.setData({
				globalOption: option
			});
		}
	},
	onShow() {
		this.init();
	},
	async init() {
		await this.getForm();
	},
	getForm() {
		this.validateForm = this.Validate({
			input: {
				required: {
					message: '不能为空哟'
				}
			},
			input1: {
				idcard: {
					message: '请输入18位的有效身份证'
				}
			},
			input2: {
				tel: {
					message: '请输入11位的手机号码'
				}
			},
			radio: {
				required: {
					message: '请至少选择一个哟'
				}
			}
		});
		if (this.globalOption && this.globalOption.id) {
			//调用数据
			let param = {
				tableName: 'form'
			};
			param = this.$tools.extend(param, this.globalOption);
			//调用数据
			this.$request.getData(param).then((data) => {
				if (data.code == 200) {
					var row = data.rows[0];
					var values = {};
					for (let key in row) {
						var keyr = key.replace(new RegExp('-', 'gm'), '');
						if (this['change' + keyr]) {
							this['change' + keyr](row[key]);
						} else {
							values[key] = row[key];
						}
					}
					this.setData(values);
				} else {
					this.showModal(data.message);
				}
			});
		}
	},
	submitForm: function (e) {
		if (!this.validateForm.checkForm(e)) {
			const error = this.validateForm.errorList[0];
			this.showToast(error.msg, 'none');
			return false;
		} else {
			this.$request.saveData(e.detail.value).then((data) => {
				if (data.code == 200) {
					this.showToast(error.msg, 'success');
				} else {
					this.showModal(data.msg);
				}
			});
		}
	},
	resetForm: function () {
		console.log('form发生了reset事件');
	},
	changeRadio(evt) {
		let value = evt.detail.value;
		let radioDatas = this.data.radioDatas;
		let radioLabel = this.data.radioLabel;
		for (var i = 0, len = radioDatas.length; i < len; ++i) {
			radioDatas[i].checked = radioDatas[i].value == value;
			if (radioDatas[i].checked) {
				radioLabel = radioDatas[i].label;
			}
		}
		this.setData({ radioLabel, radioDatas });
	}
});
