 
Page({
	data: {
		search: '',
		swiperIndex: ['0'],
		text: `<p>&nbsp; 爱宠宠物医院是专门从事宠物医疗的宠物医院，位于广东省广州市从化区，是当地广为人知的宠物医院品牌门店，收获当地宠物主人一致好评，本院业务涉及宠物医疗、美容及宠物食品、用品销售等业务范围。致力于为人民服务，成为中国基层宠物医院行业标杆。拥有专业知识丰富的宠物医生、执业经验丰富的兽医，目前正积累信息化现代化的管理经验。</p>
<div class="fkEditor-wrap" style="margin: 0px; border: 0px; outline: 0px;">&nbsp;</div>`,
		text1: `<p><strong><span style="font-size: 16pt;">医疗团队</span></strong></p>`,
		text2: `<p style="text-align: center;"><strong><span style="font-size: 14pt;">谢医生</span></strong></p>`,
		text3: `<p style="text-align: center;"><span style="font-size: 8pt;">国家注册执业兽医师</span></p>
<p style="text-align: center;"><span style="font-size: 8pt;">名牌大学兽医专业， 硕士学位</span></p>`,
		text4: `<p style="text-align: center;"><strong><span style="font-size: 14pt;">周医生</span></strong></p>`,
		text5: `<p style="text-align: center;"><span style="font-size: 8pt;">国家注册执业兽医师</span></p>
<p style="text-align: center;"><span style="font-size: 8pt;">拥有多年兽医行业从业经历，经验老到</span></p>`,
		text6: `<p style="text-align: center;"><strong><span style="font-size: 14pt;">苏助理</span></strong></p>`,
		text7: `<p style="text-align: center;"><span style="font-size: 8pt;">国家注册执业兽医师</span></p>
<p style="text-align: center;"><span style="font-size: 8pt;">医学院兽医专业，经验丰富，学士学位</span></p>`,
		text8: `<p style="text-align: center;"><strong><span style="font-size: 14pt;">刘助理</span></strong></p>`,
		text9: `<p style="text-align: center;"><span style="font-size: 8pt;">医学院兽医专业，学士学位，实习兽医，勤奋亲切</span></p>`,
		text10: `<p style="text-align: center;"><span style="color: #ecf0f1;">专业的团队，精良的技术</span></p>`,
		text11: `<p style="text-align: center;"><span style="color: #ced4d9;">PROFESSIONAL TEAM</span></p>`
	},
	onLoad(option) {
		if (option) {
			this.setData({
				globalOption: option
			});
		}
	},
	onShow() {
		this.init();
	},
	async init() {},
	changeSwiper(evt) {
		let swiperIndex = evt.detail.current;
		this.setData({ swiperIndex });
	}
});
