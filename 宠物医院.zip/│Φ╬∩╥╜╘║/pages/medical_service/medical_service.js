 
Page({
	data: {
		text: `<p>&nbsp;&nbsp;院内资深宠物医生将为宠物们提供保健服务，例如对宠物的秋冬御寒，毛发护理提出有针对性的意见和建议。</p>`,
		text2: `<p>&nbsp;&nbsp;旅游，出差？宠物无人照料？在您外出的这段时间，爱宠宠物医院将为您的宠物提供专业贴心的寄养服务。</p>`,
		text3: `<p>&nbsp;&nbsp;狗狗有咳嗽，感冒等等生病现象不知道怎么处理？宠物医生会为您的狗狗诊断治疗，为狗狗健康保驾护航。</p>`,
		text4: `<p>&nbsp;&nbsp;猫猫有呕吐，拉稀等等症状？不用担心，有多年猫病治疗经验专业宠物医生在此静候您和猫猫的到来。</p>`
	},
	onLoad(option) {
		if (option) {
			this.setData({
				globalOption: option
			});
		}
	},
	onShow() {
		this.init();
	},
	async init() {}
});
