
// login.js
var app = getApp();
Page({

	/**
	 * 页面的初始数据
	 */
	data: {
		hasUserInfo: false,
		code: null,
		//判断小程序的API，回调，参数，组件等是否在当前版本可用。
		canIUse: false,
		isShow: true,
		modal: '',
		userInfo: null,
		medical_card: null
	},

	/**
	 * 生命周期函数--监听页面加载
	 */
	onLoad: function (options) {

		//进入页面---判断全局是否有数据
		var that = this;
		console.log(app.globalData.userInfo)
		//进入页面后---获取本地存储是否有数据授权----------
		if (app.globalData.userInfo) {

			this.setData({
				isShow: false,
				userInfo: app.globalData.userInfo
			})
		} else if (this.data.canIuse) {
			// 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
			// 所以此处加入 callback 以防止这种情况
			app.userInfoReadyCallback = res => {
				that.setData({
					userInfo: res.userInfo,
					isShow: false,
				})
			}
		}
		// wx.switchTab({
		//     url: '/pages/index/index', //这里填入要跳转目的页面的url
		//     success: (result) => {
		//         console.log("跳转到首页");
		//     },
		//     fail: () => {
		//         console.log("跳转失败");
		//     }
		// });

	},

	getUserProfile(e) {
		var that = this;
		wx.getUserProfile({
			desc: '用于完善资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
			success: (res1) => {
				// 获取到用户的信息了，打印到控制台上看下
				console.log("用户的信息如下：");
				console.log(res1.userInfo);
				//授权成功后,跳转页面
				//存储全局变量-----------------
				
				app.globalData.userInfo = res1.userInfo; //存全局的账号信息
				that.setData({
					userInfo: e.detail.userInfo,
					hasUserInfo: true
				})
				var wx_nickname = res1.userInfo.nickName;
				var avatarUrl = res1.userInfo.avatarUrl;
				wx.login({
					async success (res2) {
						if (res2.code) {
						//发起网络请求
							const { data: res3 } = await wx.p.request({
								url: 'http://localhost:8080/Wx_user/login',
								data: {
									code: res2.code,
									wx_nickname: wx_nickname,
									avatar_url: avatarUrl
								}
							})
							
							console.log(res3);
							that.setData({
								medical_card : res3.list[1]
							})
							app.globalData.medical_card = res3.list[1];
						} 
						else {
							console.log('登录失败！' + res.errMsg)
						}
					}
				  })
				//授权成功后,刷新页面
				this.onLoad();
				
			},
			fail() {
				//用户按了拒绝按钮
				wx.showModal({
					title: '警告',
					content: '您拒绝了授权，将无法使用更多功能!',
					showCancel: false,
					confirmText: '返回',
					success: function (res) {
						// 用户没有授权成功，不需要改变 isHide 的值
						if (res.confirm) {
							console.log('用户点击了“返回”');
						}
					}
				});
			}
		})
	},

	// bindModal() {
	// 	wx.showModal({
	// 		title: '是否现在修改身份信息？',
	// 		success: function (res) {
	// 			if (res.confirm) {
	// 				console.log('用户点击确定')
	// 				wx.navigateTo({
	// 					url: '/pages/medical_card/medical_card'
	// 				})
	// 			}
	// 		}
	// 	})
	// },
	
});