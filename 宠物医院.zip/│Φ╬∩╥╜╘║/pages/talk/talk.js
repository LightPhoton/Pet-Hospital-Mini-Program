 
 var app = getApp();
 Page({
 	data: {
 		text6: `<p>爱宠宠物医院是专门从事宠物医疗的宠物医院，位于广东省广州市从化区，是当地广为人知的宠物医院品牌门店，收获当地宠物主人一致好评，本院业务涉及宠物医疗、美容及宠物食品、用品销售等业务范围。</p>`,
 		text5: `<p>服务挺好的</p>`,
 		text7: `<p>&nbsp;改天我带猫猫过来?</p>`,

		//可以通过hidden是否掩藏弹出框的属性，来指定那个弹出框
 		hiddenmodalput: true,
		// 存储输入框的值
		inputValue: '',
		medical_card:'',
		userInfo: null,
		talkList: [],
 	},
 	onLoad(option) {
		this.setData({
			medical_card: app.globalData.medical_card,
			userInfo: app.globalData.userInfo
		})
		
 	},
 	onShow() {
		this.setData({
			medical_card: app.globalData.medical_card,
			userInfo: app.globalData.userInfo
		})
		this.getTalk();
	},

	// input输入框的bindinput事件
  	inputCom(e){
	    this.setData({
	        inputValue: e.detail.value
	    })
	    // console.log(this.data.inputValue);
	},
	
	async getTalk(){
		
		var that = this;
		// var medical_card = that.data.medical_card;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Talk/get',
			data: {
				// medical_card: medical_card,
			}
		})
		console.log(res);
		this.setData({
			talkList:res.list
		})
		console.log(this.data.talkList);
		
	},

	async addTalk(){
		var that = this;
		console.log('input:',that.data.inputValue);
		
		var	user_name = that.data.userInfo.nickName;
		var inputValue=that.data.inputValue;
		var avatar_url = that.data.userInfo.avatarUrl;
		var medical_card = that.data.medical_card;
		const { data: res } = await wx.p.request({
			url: 'http://localhost:8080/Talk/insert',
			data: {
				user_name: user_name,
				message: inputValue,
				avatar_url: avatar_url,
				medical_card: medical_card
				
			}
		})
		console.log(res);
		this.setData({
			talkList:res.list
		})
		console.log(this.data.talkList);
	},
	
	

 	//点击按钮痰喘指定的hiddenmodalput弹出框  
 	modalinput: function () {
 		this.setData({
 			hiddenmodalput: !this.data.hiddenmodalput
 		})
 	},
 	//取消按钮  
 	cancel: function () {
 		this.setData({
 			hiddenmodalput: true
 		});
 	},
 	//确认  
 	confirm: function () {
		this.addTalk();
 		this.setData({
 			hiddenmodalput: true
 		})
 	}
 });