//Update: 邓志锋 <280160522@qq.com> <http://www.diygw.com>
export default {
    basePath: 'http://www.diygw.com',
    fileBasePath: 'http://lib.diygw.com',
    title: '宠物医院',
    debug: true,
    dashboardid:'1569',
    mpid:''
}