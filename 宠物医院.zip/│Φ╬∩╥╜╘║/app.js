
 require('./page-extend');
const app=getApp();

//实现promise化
import { promisifyAll } from 'miniprogram-api-promise'

const wxp = wx.p = {}
promisifyAll(wx, wxp)



App({
	globalData: {
		medical_card:'',
		userInfo: null,cityInfo: '',
		tabBar: ['/pages/index/index', '/pages/medical_service/medical_service', '/pages/talk', '/pages/my/my'],
		homePage: '/pages/index/index',
		pages: ['/pages/index/index', '/pages/medical_service/medical_service', '/pages/my/my', '/pages/talk/talk', '/pages/booking/booking', '/pages/medical_card', '/pages/pet/pet', '/pages/registration/registration', '/pages/medical_history/medical_history', '/pages/foods/foods', '/pages/stay/stay']
	},
	onLaunch() {
		wx.getSystemInfo({
			success: (e) => {
				this.globalData.StatusBar = e.statusBarHeight;
				let capsule = wx.getMenuButtonBoundingClientRect();
				this.globalData.WindowWidth = e.windowWidth;
				this.globalData.PixelRatio = 750 / e.windowWidth;
				if (capsule) {
					this.globalData.Custom = capsule;
					this.globalData.CustomBar = capsule.bottom + capsule.top - e.statusBarHeight;
				} else {
					this.globalData.CustomBar = e.statusBarHeight + 50;
				}
			}
		});
	},
	onShow() {},
	onHide() {}
});
